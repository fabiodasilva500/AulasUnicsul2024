from datetime import date
from Ajuda import str_para_date, date_para_str
from Ajuda import formata_cpf


class Cliente:

    cont = 1

    def __init__(self, nome, cpf, data_nascimento):
        self.__nome = nome
        self.__cpf = formata_cpf(cpf)
        self.__data_nascimento = str_para_date(data_nascimento)
        self.__data_cadastro = date.today()
        Cliente.cont += 1

    @property
    def nome(self):
        return self.__nome

    @property
    def cpf(self):
        return self.__cpf

    @property
    def data_nascimento(self):
        return date_para_str(self.__data_nascimento)

    @property
    def data_cadastro(self):
        return date_para_str(self.__data_cadastro)

