from datetime import date
from datetime import datetime


def str_para_date(data) -> date:
    return datetime.strptime(data, '%d/%m/%Y')


def date_para_str(data) -> str:
    return data.strftime('%d/%m/%Y')


def formata_moeda(valor):
    return f'R$ {valor:,.2f}'


def formata_cpf(cpf):
    return f'{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}'


def cpf_sem_formatacao(cpf):
    cpf = cpf.replace(".", "")
    cpf = cpf.replace("-", "")
    return cpf


def bissexto(ano):
    if ano % 4 == 0:
        if ano % 100 == 0:    
            if ano % 400 == 0:
                return True
            return False
        return True
    else:
        return False
