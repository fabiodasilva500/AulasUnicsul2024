from time import sleep
from Cliente import Cliente
from Conta import Conta
from Ajuda import formata_moeda, bissexto, cpf_sem_formatacao
from datetime import date
contas = []
cpfs = []
usuario: Conta


def main():
    inicio()


def menu():

    print("\n", "*" * 20, f"Bem-vindo, {usuario.cliente.nome}", "*" * 20, "\n")

    print("[1]. Transferencia")
    print("[2]. Saque")
    print("[3]. Saldo")
    print("[4]. Depósito")
    print("[5]. Sair da Conta")

    opcao = int(input())

    if opcao == 1:
        transferir()
    elif opcao == 2:
        sacar()
    elif opcao == 3:
        ver_saldo()
    elif opcao == 4:
        depositar()
    elif opcao == 5:
        print("Sessão Encerrada")
        sleep(2)
        inicio()
    else:
        print("Digite uma opção válida")
        menu()


def cadastrar_conta():
    print('Informe os dados do cliente')

    nome = input('Nome do cliente: ')
    cpf = ''

    while not cpf.isdigit() or len(cpf) != 11:
        cpf = input('Digite o CPF do cliente: ')
        if cpf.isdigit() and len(cpf) == 11:
            if cpf in cpfs:
                print("Já existe uma conta atrelada a esse cpf")
                cpf = ''
            else:
                break
        print("CPF Inválido")

    cpfs.append(cpf)

    data_nascimento = valida_data_de_nascimento()
    print(data_nascimento)
    cliente = Cliente(nome, cpf, data_nascimento)

    while True:
        senha = int(input("Escolha uma senha: "))
        if len(str(senha)) != 8:
            print("Senha fora dos padrões exigidos")
        else:
            while True:
                senha_temp = int(input("Digite a senha novamente para confirmar: "))
                if senha == senha_temp:
                    print("Senha cadastrada")
                    sleep(1)
                    break
                else:
                    print("Senhas divergem")
                    sleep(1)
            break

    conta = Conta(cliente, senha)
    contas.append(conta)

    print("Conta criada com sucesso")
    print("Dados da conta")
    print("-" * 25)
    print(conta)
    print("-" * 25)
    sleep(2)
    inicio()


def inicio():
    escolha = 0
    while escolha != 1 and escolha != 2 and escolha != 3:
        print("[1].Login\n[2].Cadastrar\n[3].Fechar")
        escolha = int(input())
        if escolha == 1:
            login()
        elif escolha == 2:
            cadastrar_conta()
        elif escolha == 3:
            print("Fechando aplicativo....")
            sleep(1)
            exit()
        print("Opção inválida")


def login():

    num_conta = int(input("Digite o numero da sua conta: "))
    conta_temp = buscar_conta(num_conta)
    if conta_temp:
        senha = 0
        while senha != conta_temp.senha:
            senha = int(input("Digite a sua senha: "))
            if senha == conta_temp.senha:
                print("Acesso liberado")
                sleep(1)
                global usuario
                usuario = conta_temp
                menu()
            else:
                print("Senha incorreta")
    else:
        print("Não foi possível encontrar a conta")
        inicio()


def transferir():

    while True:

        print("[1].TED \n[2].Pix")

        tipo = int(input("Escolha o tipo de transferência: "))

        if tipo == 1:
            num_destino = int(input("Informe o número da conta para qual deseja tranferir: "))
            conta_destino = buscar_conta(num_destino)
            break
        elif tipo == 2:
            num_destino = int(input("Informe o CPF da conta para qual deseja transferir: "))
            conta_destino = buscar_conta_cpf(num_destino)
            break
        else:
            print("Opção inválida. Tente novamente")

    while True:
        if conta_destino:
            valor = float(input("Informe o valor que deseja tranferir: "))

            if tipo == 1:
                usuario.transferir_ted(conta_destino, valor)
                break
            elif tipo == 2:
                usuario.transferir_pix(conta_destino, valor)
                break
        else:
            print("Conta não encontrada")
            transferir()

    sleep(2)
    menu()


def sacar():
    print(f"Seu saldo é {formata_moeda(usuario.saldo)}")
    valor = float(input("Informe o valor que deseja retirar: "))
    usuario.sacar(valor)
    sleep(2)
    menu()


def depositar():
    valor = float(input("Informe o valor que deseja depositar: "))
    usuario.depositar(valor)
    sleep(2)
    menu()


def ver_saldo():
    valor = usuario.saldo
    print(f"Saldo:", formata_moeda(valor))
    sleep(2)
    menu()


def buscar_conta(numero):
    c: Conta = None
    if len(contas) > 0:
        for conta in contas:
            if numero == conta.numero:
                c = conta
    return c


def buscar_conta_cpf(cpf):
    c: Conta = None
    if len(contas) > 0:
        for conta in contas:
            if cpf == int(cpf_sem_formatacao(conta.cliente.cpf)):
                c = conta
    return c


def valida_data_de_nascimento():

    print("Insira sua data de nascimento")

    while True:
        ano = input("Ano: ")
        if ano.isdigit():
            if int(ano) <= date.today().year and len(ano) == 4:
                break
            print("Digite um ano válido!")
            sleep(1)
        else:
            print("Digite um ano válido")

    while True:
        mes = input("Mês: ")
        if mes.isdigit():
            if (int(mes) < 1 or int(mes) > 12) or (len(mes) < 1 or len(mes) > 2):
                print("Digite um mês válido")
            else:
                break
        else:
            print("Digite um mês válido")

    while True:
        dia = input("Dia: ")
        if dia.isdigit():
            if (int(dia) < 1 or int(dia) > 31) or (len(mes) < 0 or len(mes) > 2):
                print("Dia inválido")
            else:
                if int(mes) == 2:
                    if bissexto(int(ano)):
                        if int(dia) > 29:
                            print("Dia inválido")
                        else:
                            break
                    else:
                        if int(dia) > 28:
                            print("Dia inválido")
                        else:
                            break
                elif int(mes) == 4 or int(mes) == 6 or int(mes) == 9 or int(mes) == 11:
                    if int(dia) > 30:
                        print("Dia inválido")
                    else:
                        break
                else:
                    break
        else:
            print("Dia inválido")

    if len(dia) == 1:
        dia = "0" + dia

    if len(mes) == 1:
        mes = "0" + mes

    data_nascimento = f"{dia}/{mes}/{ano}"
    return data_nascimento


if __name__ == '__main__':
    main()
