from time import sleep
from Ajuda import formata_moeda


class Conta:

    num = 1001

    def __init__(self, cliente, senha):
        self.__numero = Conta.num
        self.__cliente = cliente
        self.__saldo = saldo = 0.00
        self.__senha = senha
        Conta.num += 1

    def __str__(self):
        return f"Número da conta: {self.__numero} \nCliente: {self.__cliente.nome} \nCPF: {self.__cliente.cpf}" \
               f"\nData de cadastro: {self.__cliente.data_cadastro} \nSaldo: {formata_moeda(self.__saldo)}"

    @property
    def numero(self):
        return self.__numero

    @property
    def cliente(self):
        return self.__cliente

    @property
    def saldo(self):
        return self.__saldo

    @saldo.setter
    def saldo(self, valor):
        self.__saldo = valor

    @property
    def senha(self):
        return self.__senha

    @senha.setter
    def senha(self, senha):
        self.__senha = senha

    def sacar(self, valor):
        if valor > 0 and self.__saldo >= valor:
            self.__saldo -= valor
            print("Saque realizado com sucesso")
        else:
            print("Não foi possível realizar o saque")

    def transferir_ted(self, destino, valor):
        if self.__saldo >= valor:
            self.__saldo -= valor
            destino.saldo += valor
            for i in range(1, 10):
                print("Aguarde.....")
                sleep(1)
            print("Transferencia realizada")
        else:
            print("Saldo insuficiente")

    def transferir_pix(self, destino, valor):
        if self.__saldo >= valor:
            self.__saldo -= valor
            destino.saldo += valor
            print("Transferencia realizada")
        else:
            print("Saldo insuficiente")

    def depositar(self, valor):
        if valor > 0:
            self.__saldo += valor
            print("Depósito realizado")
        else:
            print("Não foi possível realizar o depósito")
