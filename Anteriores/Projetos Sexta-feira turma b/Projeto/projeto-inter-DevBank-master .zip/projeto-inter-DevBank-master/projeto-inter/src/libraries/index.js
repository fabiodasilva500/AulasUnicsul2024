import TransferFunctions from "@/libraries/transferFunctions";

const devsBankApi = {
    TransferFunctions: TransferFunctions
}

export default devsBankApi