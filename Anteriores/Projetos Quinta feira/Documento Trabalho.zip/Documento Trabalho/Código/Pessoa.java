

public class Pessoa{
    private static int contador = 1;
    private String nome; 
    private String cpf;
    private String Email; 
    private int idade;
    private int senha; 
    public Pessoa(){
        
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String email) {
        Email = email;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    public int getSenha() {
        return senha;
    }
    public void setSenha(int senha) {
        this.senha = senha;
    }
    public Pessoa(String nome, String cpf, String email, int idade, int senha) {
        this.nome = nome;
        this.cpf = cpf;
        Email = email;
        this.idade = idade;
        this.senha = senha;
        contador += 1;
        
    } 
    public String toString() {
        return "\nNome: " + this.getNome() +
                "\nCPF:" + this.getCpf() + 
                "\nEmail" + this.getEmail() +
                "\nIdade: " + this.getIdade()
                ; 
            
            
    }



    
}