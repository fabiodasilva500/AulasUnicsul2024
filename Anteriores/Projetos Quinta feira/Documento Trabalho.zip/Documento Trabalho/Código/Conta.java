

public class Conta {
   private static int numeroDeContas = 0;
    private int numeroDaConta;
    private Pessoa pessoa;
    private double saldo = 0;
    public Conta(Pessoa pessoa) {
        this.numeroDaConta = numeroDaConta;
        this.pessoa = pessoa;
        numeroDeContas += 1;
    }
    public int getNumeroDaConta() {
        return numeroDaConta;
    }
    public void setNumeroDaConta(int numeroDaConta) {
        this.numeroDaConta = numeroDaConta;
    }
    public Pessoa getPessoa() {
        return pessoa;
    }
    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
    public double getSaldo() {
        return saldo;
    }
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String toString(){
        return "\nNome: " + this.pessoa.getNome() +
        "\nNúmeroDaConta: " + this.getNumeroDaConta() +
        "\nCPF: " + this.pessoa.getCpf() + 
        "\nEmail: " + this.pessoa.getEmail() + 
        "\nSaldo: " + Paradas.doubleToString(this.getSaldo()) +
        "\n";        
    }

    public void depositar(double valor) {
        if (valor > 0) {
            setSaldo(getSaldo() + valor);
            System.out.println("Depósito feito com sucesso!");
        }
        else {
            System.out.println("Valor inválido para depósito");
        }
    }   
    public void sacar(double valor){
        if (valor > 0 && this.getSaldo() >= valor) {
            setSaldo(getSaldo() - valor);
            System.out.println("Saque feito com sucesso!");
        }
        else {
            System.out.println("Valor inválido para saque");
        }
    }

    public void transferir(Conta contaParaDeposito, double valor){    
        if (valor > 0 && this.getSaldo() >= valor) {
            setSaldo(getSaldo() - valor);
            contaParaDeposito.saldo = contaParaDeposito.getSaldo() + valor;
            System.out.println("Transferência feito com sucesso!");
        }
        else {
            System.out.println("Não foi possível fazer a transferência!");
        }
    }
    
}
