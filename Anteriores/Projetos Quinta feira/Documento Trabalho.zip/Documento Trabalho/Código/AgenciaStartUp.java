import java.util.ArrayList;

import javax.swing.JOptionPane;

public class AgenciaStartUp {
    static ArrayList<Conta> contasBancarias;

    public static void main(String[] args) {
        contasBancarias = new ArrayList<Conta>();
        funcoes();

    }
    public static void funcoes(){

        int funcoes = 
        Integer.parseInt(JOptionPane.showInputDialog("O que deseja fazer? \n" +
                    "|   Opção 1 - criar uma conta \n"  +
                    "|   Opção 2 - Transferir \n" +
                    "|   Opção 3 - Depositar \n" +
                    "|   Opção 4 - Sacar \n" +
                    "|   Opção 5 - Listar \n" +
                    "|   Opção 6 - Sair"));
       
        switch (funcoes) {
            case 1:
                criarConta();
                
                break;
                case 2:
                transferir();
                
                break;
                case 3:
                depositar();
                
                break;
                case 4:
                sacar();
                
                break;
                case 5:
                listar();
                
                break;
                case 6:
                JOptionPane.showMessageDialog(null, "Obrigado por utilizar nossos serviços!");
                System.exit(0);
                
            default:
                JOptionPane.showMessageDialog(null,"Por favor, insira uma opção válida");
                funcoes();
                break;
        }
    }

    public static void criarConta() {
        Pessoa pessoa = new Pessoa();
        pessoa.setNome(JOptionPane.showInputDialog("Nome: "));

        pessoa.setCpf(JOptionPane.showInputDialog("CPF: "));

        pessoa.setEmail(JOptionPane.showInputDialog("Email: "));

        pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));

        pessoa.setSenha(Integer.parseInt(JOptionPane.showInputDialog("Senha: ")));
       
        
        if (pessoa.getIdade()< 18) {
            JOptionPane.showMessageDialog(null, "Desculpe, você precisa ser maior de idade para utilizar nossos serviços! ");
            funcoes();
        }   
        else{
            JOptionPane.showMessageDialog(null, "Conta criada com sucesso, bem vindo! ");
            
        Conta conta = new Conta(pessoa); 
        contasBancarias.add(conta);
        funcoes();
        }
        
        
       
                    
}

    public static void transferir(){
    int trans = 
    Integer.parseInt(JOptionPane.showInputDialog("Que tipo de transferencia deseja fazer \n" +
                    "   Opção 1 - TED     \n" +
                    "   Opção 2 - Pix        \n"
                   ));
    
    switch (trans) {
        case 1:
        
        int numeroContaOrigem = 
        Integer.parseInt(JOptionPane.showInputDialog(null, "Número da conta de origem:  "));
        Conta contaOrigem = encontrarConta(numeroContaOrigem);
        
        System.out.println("Número da conta de destino: ");
       
        if (contaOrigem != null) {
            int numeroContaDestino =
            Integer.parseInt(JOptionPane.showInputDialog(null, "Número da conta de destino:  "));
            Conta contaDestino = encontrarConta(numeroContaDestino);
            if (contaDestino != null) {
                Double valor = 
                Double.parseDouble(JOptionPane.showInputDialog(null, "Qual valor deseja transferir: "));
                contaOrigem.transferir(contaDestino, valor);
               JOptionPane.showMessageDialog(null, "Transferencia realizada com sucesso! ");
            }
            else {
                JOptionPane.showMessageDialog(null, "Conta de destino não encontrada! ");
            }
             funcoes();
             break;
        }
        case 2: 
        transpix();
    
            break;
    
        default:
        System.out.println("Opção inválida.");
            break;
    }
    
         funcoes();
}   
    private static Conta encontrarConta(int numeroConta){
        Conta conta = null;
        if (contasBancarias.size() > 0) {
            for(Conta c: contasBancarias){
                if(c.getNumeroDaConta() == numeroConta);
                conta = c;
            }
        }   return conta;
    }
    public static void depositar(){
        int numeroConta = 
            Integer.parseInt(JOptionPane.showInputDialog(null, "Número da conta para depósito: "));
            Conta conta = encontrarConta(numeroConta);
        if (conta != null) {
            System.out.println("Qual valor deseja depositar? ");
            Double valorDeposito = Double.parseDouble(JOptionPane.showInputDialog(null, "Qual valor deseja depositar: "));
            conta.depositar(valorDeposito);
            JOptionPane.showMessageDialog(null, "Depósito feito com sucesso! ");
        }
        else {
            JOptionPane.showMessageDialog(null, "Conta não encontrada! ");
            
        }
        funcoes();
    }
    public static void sacar(){
       int numeroConta = 
        Integer.parseInt(JOptionPane.showInputDialog("Número de conta para saque: "));
        Conta conta = encontrarConta(numeroConta);
        if (conta != null) {
            
            Double valorSaque = 
            Double.parseDouble(JOptionPane.showInputDialog("Qual valor deseja sacar: ")); 
            conta.sacar(valorSaque);
            JOptionPane.showMessageDialog(null, "Saque feito com sucesso! ");
          
        }
        else {
            JOptionPane.showMessageDialog(null, "Conta não encontrada! ");
        }
        funcoes();
    }
    public static void listar(){
        if (contasBancarias.size() > 0) {
           for(Conta conta: contasBancarias){
            JOptionPane.showMessageDialog(null, conta);
            
           }
        }
        else {
            JOptionPane.showMessageDialog(null, "Conta não encontrada! ");
        }
        funcoes();
    }
    public static void transpix(){
        int transpix = 
    Integer.parseInt(JOptionPane.showInputDialog("Qual seria o tipo de chave PIX ?: \n" +
                    "   Opção 1 - CPF    \n" +
                    "   Opção 2 - Telefone         \n" +
                    "   Opção 3 - Email \n" +
                    "   Opção 4 - Chave aleatória \n"
                   ));
        
      
        if (transpix == 1) {
           JOptionPane.showInputDialog(null, "Por favor, digite o CPF: ");
            
            
        }

        else if (transpix == 2) {
            JOptionPane.showInputDialog(null, "Por favor, digite o telefone: ");
            
            
           
            
        }
        else if (transpix == 3) {
            JOptionPane.showInputDialog(null, "Por favor, digite o Email: ");
           
           
        }   
        else if (transpix == 4){
            JOptionPane.showInputDialog(null, "Por favor, digite o Chave aleatória: ");
           
            
        }    
        else {
            JOptionPane.showMessageDialog(null, "Opção Inválida! ");

            
        }
            
        
       
        Double valor = 
        Double.parseDouble(JOptionPane.showInputDialog(null, "Qual valor deseja transferir: "));
        JOptionPane.showMessageDialog(null, "Transferencia realizada com sucesso !");
        
        
        
       
       
        }
    }
       

    


