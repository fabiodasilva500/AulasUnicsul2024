
/**
 *
 * @author Fabio
 */
public class NO {
	public Livro livro;
	public NO prox;

	public NO(Livro l){
		livro=l;
		prox=null;
	}
}






