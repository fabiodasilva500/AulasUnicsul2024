/**
 *
 * @author Fabio
 */
public class NO {
	public int dado;
	public NO prox;

	public NO(int e){
		dado=e;
		prox=null;
	}
}






