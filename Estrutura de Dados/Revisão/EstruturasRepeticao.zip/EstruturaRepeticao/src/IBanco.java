
public interface IBanco {
	public void adicionar(Banco bc);
	public void remover (int id);
	public void atualizar(Banco bc);
}
