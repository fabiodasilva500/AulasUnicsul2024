import java.io.*;
import javax.swing.JOptionPane;            //importando a classe JOptionPane
public class CaixaEletronico {            //declaração de uma classe pública

//abaixo segue a declaração de todas as variáveis e vetores
//que formarão a estrutura do caixa
static int acessar,voltar;
static int valores[]= new int [6];
static int i;
static int totais[]= new int [6];
static int total_geral;

static int s_erros,senha, banco,saque;
static int bmaior[]= new int [4];
static int b,bmenor[]= new int [4];
static double soma_saque,soma_quant;
static int total_disponivel, s[]= new int [6];


static int bcmaior_saque,bcmenor_saque;
static double m_saques;


static int x;
static String arquivo="Caixa.txt";                             //criando o arquivo txt
public static void main(String[] args) throws IOException {    //declaração do método void que não possui retorno
Clientes[]clientes=new Clientes[5];



//inicializando todas as posições dos vetores
//que irão armazenar os bancos de maior e de menor saque
for (b=0;b<4;b++)
{
bmaior[b]=0;
bmenor[b]=10000000;
}
total_geral=0;     //inicializando a variável total_geral
voltar=15;        //a variável voltar esta recebendo 15
                  //e sempre quando ela estiver com este valor
                  //o programa irá retornar ao menu inicial


while (voltar==15){                        //sempre quando a variável voltar tiver conteúdo
                                           //igual a 15 o programa retornará ao menu principal

acessar=Integer.parseInt(JOptionPane.showInputDialog("1-Cadastrar Clientes\n2-Consultar Conta\n3-Carregar Caixa\n4-Saque\n5-Estatística\n6-Finalizar operação"));   //o usuário informa de acordo com as opções qual opção do caixa ele deseja acessar

//realizando um tratamento de erro na variável acessar para que o usuário só possa inserir valores válidos
while((acessar<=0)||(acessar>=7)){
acessar=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente conforme descrito abaixo:\n1-Cadastrar Clientes\n2-Consultar Conta\n3-Carregar Caixa\n4-Saque\n5-Estatística\n6-Finalizar operação"));
}

//se o usuário digitar qualquer opção exceto a de cadastro de clientes o arquivo será carregado para a memória
if (acessar!=1){
BufferedReader ler=new BufferedReader(new FileReader(arquivo));
for (x=0;x<=4;x++)
clientes[x]=new Clientes();

for (x=0;x<=4;x++)
{
clientes[x].nome=ler.readLine();
clientes[x].rg=ler.readLine();
clientes[x].cpf=ler.readLine();
clientes[x].endereco=ler.readLine();
clientes[x].telefone=ler.readLine();
clientes[x].banco=Integer.parseInt(ler.readLine());
clientes[x].conta=Integer.parseInt(ler.readLine());
clientes[x].senha=Integer.parseInt(ler.readLine());
clientes[x].saldo=Double.parseDouble(ler.readLine());
}
ler.close();
}

switch (acessar) {
case 1:
rot_cadastrar_clientes(clientes);
break;
case 2:
rot_consultar_conta(clientes);
break;
case 3:
rot_carregar();
break;
case 4:
rot_saque(clientes);
break;
case 5:
rot_estatistica();
break;
default:
rot_finalizar();

}      //finalizando o switch case
}      //finalizando a estrutura enquanto
}      //finalizando o método void


public static void rot_cadastrar_clientes(Clientes[]clientes) throws IOException{

//rotina de escrita de cadastro de clientes no arquivo txt
s_erros=1;  //inicializando a variável s_erros

senha=Integer.parseInt(JOptionPane.showInputDialog("Caro funcionário, por favor insira a sua senha de acesso"));   //o administrador do banco deve informar a senha de acesso para consultar  a quantidade de notas disponíveis

while(senha!=1229 && senha!=3341 && senha!=4440 && s_erros<3) {   //enquanto ele errar a senha e enquanto o número total de erros não exceda 3 aparecerá a mensagem abaixo
senha=Integer.parseInt(JOptionPane.showInputDialog("Senha inválida, por favor tente novamente, caso o número de erros chegue a\ntrês o sistema retornará automaticamente menu"));
s_erros=(s_erros+1);    //a cada erro s_erros soma a quantidade de vezes em que eles ocorreram
}
if(s_erros==4){
JOptionPane.showMessageDialog(null,"Você errou 3 vezes a sua senha, o sistema irá retornar ao menu,\npor favor verifique o problema antes de tentar novamente");
voltar=15;
System.out.println(s_erros);
}
else
if ((senha==1229)||(senha==3341)||(senha==4440)){


BufferedWriter escreva=new BufferedWriter(new FileWriter(arquivo));
for (x=0;x<=4;x++)
clientes[x]=new Clientes();

for (x=0;x<=4;x++)
{
clientes[x].nome=JOptionPane.showInputDialog("Informe o nome completo do cliente");
escreva.write(clientes[x].nome);
escreva.newLine();
clientes[x].rg=JOptionPane.showInputDialog("Informe o RG completo do cliente");
escreva.write(clientes[x].rg);
escreva.newLine();
clientes[x].cpf=JOptionPane.showInputDialog("Informe o CPF do cliente");
escreva.write(clientes[x].cpf);
escreva.newLine();
clientes[x].endereco=JOptionPane.showInputDialog("Informe o endereço do cliente");
escreva.write(clientes[x].endereco);
escreva.newLine();
clientes[x].telefone=JOptionPane.showInputDialog("Informe o telefone do cliente");
escreva.write(clientes[x].telefone);
escreva.newLine();
clientes[x].banco=Integer.parseInt(JOptionPane.showInputDialog("Informe o número do banco que o cliente utiliza.\n1-Itaú\n2-Santander\n3-Bradesco\n4-HSBC"));
while((clientes[x].banco<=0)||(clientes[x].banco>=5)){
clientes[x].banco=Integer.parseInt(JOptionPane.showInputDialog("O caixa eletrônico não trabalha com o banco requerido,\npor favor informe de acordo com as opções abaixo:\n1-Itaú\n2-Santander\n3-Bradesco\n4-HSBC"));
}
escreva.write(Integer.toString(clientes[x].banco));
escreva.newLine();
clientes[x].conta=Integer.parseInt(JOptionPane.showInputDialog("Informe o número da conta"));
escreva.write(Integer.toString(clientes[x].conta));
escreva.newLine();
clientes[x].senha=Integer.parseInt(JOptionPane.showInputDialog("Prezado cliente, informe a senha que você deseja utilizar"));
escreva.write(Integer.toString(clientes[x].senha));
escreva.newLine();
clientes[x].saldo=Double.parseDouble(JOptionPane.showInputDialog("Informe o saldo do cliente"));
escreva.write(Double.toString(clientes[x].saldo));
escreva.newLine();
}
escreva.close();
voltar=15;

}
}

public static void rot_consultar_conta(Clientes[]clientes) throws IOException{
int pesquisa;

//abaixo será realizado o tratamento de erro para que somente possam ser consultadas contas,
//por pessoas que possuam a senha de acesso ao caixa
s_erros=1;
senha=Integer.parseInt(JOptionPane.showInputDialog("Caro funcionário, por favor insira a sua senha de acesso"));
while(senha!=1229 && senha!=3341 && senha!=4440 && s_erros<3) {
senha=Integer.parseInt(JOptionPane.showInputDialog("Senha inválida, por favor tente novamente e caso o número de erros\nchegue a três o sistema retornará automaticamente menu"));
s_erros=(s_erros+1);
}

//se o usuário informar a senha correta ele digitará o nº da conta que deseja localizar
//e se ela for encontrada através da estrutura abaixo a mesma será exibida, caso contrário
//retornará ao menu de opções

if ((senha==1229)||(senha==3341)||(senha==4440)){
pesquisa=Integer.parseInt(JOptionPane.showInputDialog("Informe o número da conta que você deseja consultar,\nse ela não for localizada o sistema retornará ao menu automaticamente"));

for (x=0;x<=4;x++){
{
if (pesquisa==clientes[x].conta){
JOptionPane.showMessageDialog(null,"Dados da conta:\nNome:"+clientes[x].nome+"\nRG:"+clientes[x].rg+"\nCPF:"+clientes[x].cpf+"\nEndereço:"+clientes[x].endereco+"\nTelefone:"+clientes[x].telefone+"\nBanco:"+clientes[x].banco+"\nConta:"+clientes[x].conta+"\nSaldo:"+clientes[x].saldo);
}
}
}
}
}

public static void rot_carregar(){             //declarando o método rot_carregar
s_erros=1;  //inicializando a variável s_erros

senha=Integer.parseInt(JOptionPane.showInputDialog("Caro funcionário, por favor insira a sua senha de acesso"));   //o administrador do banco deve informar a senha de acesso para consultar  a quantidade de notas disponíveis

while(senha!=1229 && senha!=3341 && senha!=4440 && s_erros<3) {   //enquanto ele errar a senha e enquanto o número total de erros não exceda 3 aparecerá a mensagem abaixo
senha=Integer.parseInt(JOptionPane.showInputDialog("Foi informada uma senha inválida, por favor tente novamente e caso o número\nde erros chegue a três o sistema retornará automaticamente ao menu"));
s_erros=(s_erros+1);    //a cada erro s_erros soma a quantidade de vezes em que eles ocorreram
}

if(senha==1229 || senha==3341 || senha==4440){      //caso o administrador acerte uma das senhas

for (i=0;i<=5;i++)
{
if (i==0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 2 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 2 reais\nque o caixa irá ter"));
}
}
if(i==1){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 5 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 5 reais\nque o caixa irá ter"));
}
}
if(i==2){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 10 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 10 reais\nque o caixa irá ter"));
}
}
if(i==3){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 20 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 20 reais\nque o caixa irá ter"));
}
}

if(i==4){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 50 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 50 reais\nque o caixa irá ter"));
}
}

if(i==5){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de notas de 100 reais que o caixa irá ter"));
while(valores[i]<0){
valores[i]=Integer.parseInt(JOptionPane.showInputDialog("Você informou um valor inválido, por favor insira novamente a quantidade de notas de 100 reais\nque o caixa irá ter"));
}
}
}

//calculando o total disponível de cada nota e armazenando
//em cada posição do vetor totais
totais[0]=valores[0]*2;
totais[1]=valores[1]*5;
totais[2]=valores[2]*10;
totais[3]=valores[3]*20;
totais[4]=valores[4]*50;
totais[5]=valores[5]*100;


for (i=0;i<=5;i++)
{
total_geral=(total_geral+totais[i]);       //calculando o total disponível no caixa
}
total_disponivel=total_geral;              //a variável total disponível está
                                           //recebendo o conteúdo da variável total_geral
JOptionPane.showMessageDialog(null,"O valor total disponível em cada tipo de nota é igual á:\n2 reais:"+totais[0]+"\n5 reais:"+totais[1]+"\n10 reais:"+totais[2]+"\n20 reais:"+totais[3]+"\n50 reais:"+totais[4]+"\n100 reais:"+totais[5]); //a quantidade de cada nota disponível será exibida
JOptionPane.showMessageDialog(null,"O valor total disponível no caixa é igual á:\n"+total_disponivel);    //exibindo também o total disponível no caixa
voltar=15;      //voltar recebe 15, assim o programa irá retornar ao menu inicial
}          //finalizando a estrutura de decisão acima

}      //finalizando o método rot_carregar

public static void rot_saque(Clientes[]clientes) throws IOException{           //declarando o método rot_saque
int p_banco,p_senha,auxiliar=0,erros=0;
p_banco=Integer.parseInt(JOptionPane.showInputDialog("Informe o banco que você utiliza\n1-Itaú\n2-Santander\n3-Bradesco\n4-HSBC"));

//se o usuário informar um número bancário que o caixa não trabalha será realizado o tratamento de erro

p_senha=Integer.parseInt(JOptionPane.showInputDialog("Informe a sua senha de acesso"));
x=0;

//enquanto o usuário errar banco e/ou senha o tratamento de erro será executado,
//se ele errar 3 vezes o sistema retorna ao menu, se ele acertar inicializa-se
//o rotina inicial de saque
while((auxiliar!=1)&&(erros<=3)&&(x<=4)){
if((p_banco==clientes[x].banco)&&(p_senha==clientes[x].senha)){
auxiliar=1;
rot_inicio(clientes,p_banco);
}
else{
x=x+1;
}
if((x==5)&&(auxiliar!=1)){
erros=erros+1;

if(erros==3){
JOptionPane.showMessageDialog(null,"Você errou 3 vezes o banco que você utiliza e/ou a sua senha, o sistema irá retornar ao menu,\npor favor verifique o problema antes de tentar novamente");
voltar=15;
}
else{
if(s_erros<3){
p_banco=Integer.parseInt(JOptionPane.showInputDialog("Você digitou o banco ou a senha de acesso inválidos, por favor digite o número do banco que você utiliza\n1-Itaú\n2-Santander\n3-Bradesco\n4-HSBC"));
p_senha=Integer.parseInt(JOptionPane.showInputDialog("Digite novamente a sua senha"));
x=0;   
}
}
}
}
}


public static void rot_inicio(Clientes[] clientes, int p_banco) throws IOException {
if(soma_quant>=1000){                     //se o número de saques chegar a 1000 saques não serão mais realizados, pois o limite máximo será atingido
JOptionPane.showMessageDialog(null,"Limite máximo de saques atingidos");
voltar=15;   //retornando ao menu inicial
}
else

if (soma_quant<1000){                    //se o número de saques for menor que 100
JOptionPane.showMessageDialog(null,"Notas disponíveis");


for (i=0;i<6;i++) {
s[i]=0;                                //inicializando todas as posições do vetor s[i] que posteriormente irá armazenar a quantidade de cada tipo de nota sacada
if (i==0 && valores[i]>0) {            //se i for igual á zero e a posição 0 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"2 reais");    //há notas de 2 reais
}
if (i==1 && valores[i]>0) {            //se i for igual á um e a posição 1 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"5 reais");    //há notas de 5 reais
}
if (i==2 && valores[i]>0) {            //se i for igual á dois e a posição 2 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"10 reais");   //há notas de 10 reais
}
if (i==3 && valores[i]>0) {            //se i for igual á três e a posição 3 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"20 reais");   //há notas de 20 reais
}
if (i==4 && valores[i]>0) {            //se i for igual a 4 e a posição 4 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"50 reais");   //há notas de 50 reais
}
if (i==5 && valores[i]>0) {           //se i for igual a 5 e a posição 5 do vetor valores for maior que zero
JOptionPane.showMessageDialog(null,"100 reais");  //há notas de 100 reais
}
    }     //finalizando a estrutura de repetição


if (total_disponivel>=2) {              //se o total disponível no caixa for maior ou igual á 2
banco=p_banco;

saque=Integer.parseInt(JOptionPane.showInputDialog("Informe o valor que você deseja sacar"));   //o usuário informa o valor que ele deseja sacar

//se o usuário informar valores inferiores ao seu saldo ou informar para saque, um real por exemplo
// o sistema exibirá a mensagem de erro, juntamente com o saldo do cliente e retornará ao menu
if (((clientes[x].saldo<saque)||(saque<=1)||(saque>=total_disponivel))){
JOptionPane.showMessageDialog(null,"Você não pode sacar a quantia desejada ou o valor solicitado não encontra-se disponível em caixa.\nO sistema irá retornar ao menu, mas antes verifique ao lado seu saldo atual: R$"+clientes[x].saldo);
voltar=15;
}

else
if (saque<=total_disponivel){     //se o conteúdo de saque for menor ou igual ao total disponível

if(banco==1){                 //se o banco que ele utiliza for o primeiro
b=0;                          //b recebe 0, para que se verifique o maior e o menor saque do banco 1
if (saque>bmaior[b]) {        //se saque for maior que o conteúdo de bmaior da posição 0
bmaior[b]=saque;              //bmaior da posição zero recebe saque
    }
if (saque<=bmenor[b]){        //se saque for menor ou igual a bmenor da posição 0
bmenor[b]=saque;              //bmenor da posição zero recebe saque
    }
    }

//todo este processo ocorrerá com os outros 3 bancos
if(banco==2){                 //se o banco que ele utiliza for o segundo
b=1;                          //b recebe 1, para que se verifique o maior e o menor saque do banco 2
if (saque>bmaior[b]) {        //se saque for maior que bmaior da posição 1
bmaior[b]=saque;              //bmaior da posição 1 recebe saque
    }
if (saque<=bmenor[b]){        //se saque for menor ou igual a bmenor da posição 1
bmenor[b]=saque;              //bmenor da posição 1 recebe saque
    }
    }

if(banco==3){                //se o banco que ele utiliza for o terceiro
b=2;                         //b recebe 2, para que se verifique o maior e o menor saque do banco 3
if (saque>bmaior[b]) {       //se saque for maior que bmaior da posição 2
bmaior[b]=saque;             //bmaior da posição 2 recebe saque
    }
if (saque<=bmenor[b]){       //se saque for menor ou igual que bmenor da posição 2
bmenor[b]=saque;             //bmenor da posição 2 recebe saque
    }
    }
if(banco==4){                //se o banco que ele trabalha for o quarto
b=3;                         //b recebe 3, para que se verifique o maior e o menor saque do banco 4
if (saque>bmaior[b]) {       //se saque for maior que bmaior da posição 3
bmaior[b]=saque;             //bmaior da posição 3 recebe saque
    }
if (saque<=bmenor[b]){       //se saque for menor ou igual que bmenor da posição 3
bmenor[b]=saque;             //bmenor da posição 3 recebe saque
    }
    }

rot_processamento(clientes);         //está sendo chamada a rotina de processamento que irá realizar
                             //o saque das notas disponíveis de acordo com o valor requerido pelo usuário
}
}
}
}





public static void rot_processamento(Clientes[]clientes) throws IOException{              //declarando o método rot_processamento
i=5;
//a variável i recebe 5 pois será decrementada posterior a cada saque
clientes[x].saldo=clientes[x].saldo-saque;
soma_quant=(soma_quant+1);                           //soma_quant recebe o conteúdo dela mais 1, pois está sendo realizado um novo saque
soma_saque=soma_saque+saque;                         //soma_saque recebe o conteúdo dela mais o da variável saque, pois também está sendo realizado um novo saque
total_disponivel=(int) (total_geral-soma_saque);     //total_disponivel recebe o conteúdo convertido para inteiro da subtração de total_geral e a soma dos saques

while(i>=0) {                                        //enquanto i for maior ou igual á 0 serão buscadas as notas para o saque

while (i==5 && valores[i]>=1 && saque>=100){         //enquanto i for igual á 5, houver uma ou mais notas de 100 e saque for maior ou igual á 100 reais
valores[i]=(valores[i]-1);        //retirando uma nota de 100 reais
totais[i]=(totais[i]-100);        //retirando 100 reais
saque=(saque-100);                //retirando 100 reais do saque
s[i]=(s[i]+1);                    //acrescentando uma nota de 100 reais ao saque
}

if (valores[i]==0) {                       //se não houverem notas de 100 reais
while(valores[i-1]>=2 && saque>=100){      //se houverem duas ou mais notas de 50 reais e saque for maior ou igual á 100 reais
valores[i-1]=(valores[i-1]-2);             //retirando 2 notas de 50 reais
totais[i-1]=(totais[i-1]-100);              //retirando 100 reais do conteúdo em notas de 50 reais

valores[i]=(valores[i]+1);                  //acrescentando uma nota de 100 reais
totais[i]=(totais[i]+100);                  //retirando uma nota de 100 reais

valores[i]=(valores[i]-1);                  //retirando a nota acrescentada
totais[i]=(totais[i]-100);                  //retirando os 100 reais acrescentados
saque=(saque-100);                          //retirando 100 reais do saque
s[i]=s[i]+1;                                //acrescentando uma nota de 100 reais ao saque
}
}

if(valores[i-1]<2) {                       //se não houverem pelo menos duas notas de 50 reais
while(valores[i-2]>=5 && saque>=100){      //enquanto houverem 5 ou mais notas de 20 reais e saque for maior ou igual á 100
valores[i-2]=(valores[i-2]-5);             //retirando 5 notas de 20 reais
totais[i-2]=(totais[i-2]-100);             //retirando 100 reais do conteúdo em notas de 20 reais

valores[i]=(valores[i]+1);                 //acrescentando uma nota de 100 reais
totais[i]=(totais[i]+100);                 //acrescentando 100 reais
valores[i]=(valores[i]-1);                 //retirando a nota de 100 reais acrescentada
totais[i]=(totais[i]-100);                 //retirando os 100 reais acrescentados

saque=(saque-100);                         //retirando 100 reais do saque
s[i]=s[i]+1;                               //acrescentando uma nota de 100 reais ao saque

}
    }

if (valores[i-2]<5) {                     //se não houverem pelo menos 5 notas de 20 reais
while(valores[i-3]>=10 && saque>=100) {   //enquanto houverem 10 ou mais notas de 10 reais e saque for maior ou igual á 100
valores[i-3]=(valores[i-3]-10);           //retirando 10 notas de 10 reais
totais[i-3]=(totais[i-3]-100);            //retirando 100 reais do conteúdo em notas de 100 reais

valores[i]=(valores[i]+1);                //acrescentando uma nota de 100 reais
totais[i]=(totais[i]+100);                //acrescentando 100 reais
valores[i]=(valores[i]-1);                //retirando a nota de 100 reais acrescentada
totais[i]=(totais[i]-100);                //retirando os 100 reais acrescentados

saque=(saque-100);                        //retirando 100 reais do saque
s[i]=(s[i]+1);                            //acrescentando uma nota de 100 reais ao saque

}
}

if (valores[i-3]<10){                    //se não houverem pelo menos 10 notas de 10 reais
while(valores[i-4]>=20 && saque>=100){   //se houverem 20 ou mais notas de 5 reais e saque for maior ou igual á 100 reais
valores[i-4]=(valores[i-4]-20);          //retirando 20 notas de 5 reais
totais[i-4]=(totais[i-4]-100);           //retirando 100 reais do conteúdo em notas de 20 reais

valores[i]=(valores[i]+1);               //acrescentando uma nota de 100 reais
totais[i]=(totais[i]+100);               //acrescentando 100 reais
valores[i]=(valores[i]-1);               //retirando a nota de 100 reais acrescentada
totais[i]=(totais[i]-100);               //retirando os 100 reais acrescentados

saque=(saque-100);                       //retirando 100 reais do saque
s[i]=(s[i]+1);                           //acrescentando uma nota de 100 reais ao saque
    }
}

if(valores[i-4]<20){                     //se não houverem pelo menos 20 notas de 5 reais
while(valores[i-5]>=50 && saque>=100) {  //enquanto houverem 50 ou mais notas de 2 reais e saque for maior ou igual á 100 reais
valores[i-5]=(valores[i-5]-50);          //retirando 100 reais do conteúdo em notas de 2 reais
totais[i-5]=(totais[i-5]-100);

valores[i]=(valores[i]+1);               //acrescentando uma nota de 100 reais
totais[i]=(totais[i]+100);               //acrescentando 100 reais no total em notas de 100
valores[i]=(valores[i]-1);               //retirando a nota de 100 acrescentada
totais[i]=(totais[i]-100);               //retirando os 100 reais acrescentados

saque=(saque-100);                       //retirando 100 reais do saque
s[i]=(s[i]+1);                           //acrescentando uma nota de 100 reais ao saque
}
}

i=i-1;                                  //i a partir de agora passa a valer 4, ou seja serão buscadas notas de 50 reais para o saque


while (i==4 && valores[i]>=1 && saque>=50){     //enquanto i for igual á 4, houverem notas de 50 reais e saque for maior ou igual á 50
valores[i]=(valores[i]-1);                      //retirando uma nota de 50 reais
totais[i]=(totais[i]-50);                       //retirando 50 reais
saque=(saque-50);                               //retirando 50 reais do saque
s[i]=(s[i]+1);                                  //acrescentando uma nota de 50 reais ao saque
}

if (valores[i]==0) {                            //se não houverem notas de 50 reais
while(valores[i-1]>=2 && valores[i-2]>=1 && saque>=50){         //se houverem 2 ou mais notas de 20 reais, uma ou mais notas de 10 reais e saque for maior ou igual á 50
valores[i-1]=(valores[i-1]-2);                   //retirando duas notas de 20 reais
totais[i-1]=(totais[i-1]-40);                    //retirando 40 reais do total disponível em notas de 20 reais

valores[i-2]=(valores[i-2]-1);                   //retirando uma nota de 10 reais
totais[i-2]=(totais[i-2]-10);                    //retirando 10 reais do total disponível em notas de 10 reais

valores[i]=(valores[i]+1);                       //acrescentando uma nota de 50 reais
totais[i]=(totais[i]+50);                        //acrescentando 50 reais

valores[i]=(valores[i]-1);                       //retirando a nota de 50 reais acrescentada
totais[i]=(totais[i]-50);                        //retirando os 50 reais acrescentados
saque=(saque-50);                                //retirando 50 reais do saque
s[i]=s[i]+1;                                     //acrescentando uma nota de 50 reais
}
}

if(valores[i-1]<2) {                            //se não houverem pelo menos duas notas de 20 reais
while(valores[i-2]>=5 && saque>=50){            //enquanto houverem 5 ou mais notas de 10 reais e saque for maior ou igual á 50
valores[i-2]=(valores[i-2]-5);                  //retirando 5 notas de 10 reais
totais[i-2]=(totais[i-2]-50);                   //retirando 50 reais do total disponível em notas de 10 reais

valores[i]=(valores[i]+1);                      //acrescentando uma nota de 50 reais
totais[i]=(totais[i]+50);                       //acrescentando 50 reais no total disponível em notas de 50 reais
valores[i]=(valores[i]-1);                      //retirando a nota de 50 reais acrescentada
totais[i]=(totais[i]-50);                       //retirando os 50 reais acrescentados

saque=(saque-50);                               //retirando 50 reais do total do saque
s[i]=s[i]+1;                                    //acrescentando uma nota de 50 reais ao saque
}
}

if (valores[i-2]<5){                           //se não houverem pelo menos 5 notas de 10 reais
while(valores[i-3]>=10 && saque>=50){          //enquanto houverem 10 ou mais notas de 5 reais e saque for maior ou igual á 50
valores[i-3]=(valores[i-3]-10);                //retirando 10 notas de 5 reais
totais[i-3]=(totais[i-3]-50);                  //retirando 50 reais do total disponível em notas de 5 reais

valores[i]=(valores[i]+1);                     //acrescentando uma nota de 50 reais
totais[i]=(totais[i]+50);                      //acrescentando 50 reais no total disponível em notas de 50 reais
valores[i]=(valores[i]-1);                     //retirando a nota de 50 reais acrescentada
totais[i]=(totais[i]-50);                      //retirando os 50 reais acrescentados

saque=(saque-50);                              //retirando 50 reais do saque
s[i]=(s[i]+1);                                 //acrescentando uma nota de 50 reais ao saque
    }
}

if (valores[i-3]<10){                         //se não houverem pelo menos 10 notas de 5 reais
while(valores[i-4]>=25 && saque>=50){         //enquanto houverem 25 ou mais notas de 2 reais e saque for maior ou igual á 50
valores[i-4]=(valores[i-4]-25);               //retirando 25 notas de 2 reais
totais[i-4]=(totais[i-4]-50);                 //retirando 50 reais do total disponível em notas de 5 reais

valores[i]=(valores[i]+1);                    //acrescentando uma nota de 50 reais
totais[i]=(totais[i]+50);                     //acrescentando 50 reais ao total disponível em notas de 50 reais
valores[i]=(valores[i]-1);                    //retirando a nota de 50 reais acrescentada
totais[i]=(totais[i]-50);                     //retirando os 50 reais acrescentados

saque=(saque-50);                             //retirando 50 reais do total do saque
s[i]=(s[i]+1);                                //acrescentando uma nota de 50 reais ao saque
}
}

i=i-1;                                       //i á partir de agora passa a valer 3, para que sejam buscadas para o saque notas de 20 reais

while (i==3 && valores[i]>=1 && saque>=20){       //enquanto i for igual á 3, houverem pelo menos uma nota e 20 reais e saque for maior ou igual á 20 reais
valores[i]=(valores[i]-1);                        //retirando uma nota de 20 reais
totais[i]=(totais[i]-20);                         //retirando 20 reais do total disponível em notas de 20 reais
saque=(saque-20);                                 //retirando 20 reais do saque
s[i]=(s[i]+1);                                    //acrescentando uma nota de 20 reais ao saque
}

if(valores[i]==0) {                               //se não houverem notas de 20 reais
while(valores[i-1]>=2 && saque>=20){              //enquanto houverem pelo menos 2 notas de 10 reais e saque for maior ou igual á 20
valores[i-1]=(valores[i-1]-2);                    //retirando 2 notas de 10 reais
totais[i-2]=(totais[i-2]-20);                     //retirando 20 reais do conteúdo disponível em notas de 20 reais

valores[i]=(valores[i]+1);                        //acrescentando uma nota de 20 reais ao saque
totais[i]=(totais[i]+20);                         //acrescentando 20 reais no total disponível em notas de 20
valores[i]=(valores[i]-1);                        //retirando a nota de 20 reais acrescentada
totais[i]=(totais[i]-20);                         //retirando os 20 reais acrescentados

saque=(saque-20);                                 //retirando 20 reais do saque
s[i]=s[i]+1;                                      //acrescentando ao saque uma nota de 20 reais
}
}


if(valores[i-1]<2) {                             //se não houverem pelo menos 2 notas de 10 reais
while(valores[i-2]>=4 && saque>=20){             //enquanto houverem pelo menos 4 notas de 5 reais e saque for maior ou igual á 50
valores[i-2]=(valores[i-1]-4);                   //retirando 4 notas de 5 reais
totais[i-2]=(totais[i-2]-20);                    //retirando 20 reais do total disponível em notas de 5 reais

valores[i]=(valores[i]+1);                       //acrescentando uma nota de 20 reais
totais[i]=(totais[i]+20);                        //acrescentando 20 reais ao total disponível em notas de 20 reais
valores[i]=(valores[i]-1);                       //retirando a nota de 20 acrescentada
totais[i]=(totais[i]-20);                        //retirando os 20 reais acrescentados

saque=(saque-20);                                //retirando 20 reais do saque
s[i]=s[i]+1;                                     //acrescentando uma nota de 20 reais ao saque
}
}

if(valores[i-2]<4) {                             //se não houverem pelo menos 4 notas de 5 reais
while(valores[i-3]>=10 && saque>=20){            //enquanto houverem pelo menos 10 notas de 2 reais e saque for maior ou igual a 50
valores[i-3]=(valores[i-3]-10);                  //retirando 10 notas de 2 reais
totais[i-3]=(totais[i-3]-20);                    //retirando 20 reais do total disponível em notas de 2 reais

valores[i]=(valores[i]+1);                       //acrescentando uma nota de 20 reais
totais[i]=(totais[i]+20);                        //acrescentando 20 reais ao total disponível em notas de 20 reais
valores[i]=(valores[i]-1);                       //retirando a nota acrescentada
totais[i]=(totais[i]-20);                        //retirando os 20 reais acrescentados

saque=(saque-20);                                //retirando 20 reais do saque
s[i]=s[i]+1;                                     //acrescentando uma nota de 20 reais ao saque
}
}

i=i-1;                                           //i a partir de agora passa a valer 3, para que sejam buscadas notas de 10 reais para o saque

while (i==2 && valores[i]>=1 && saque>=10){      //enquanto i for igual á 2,houver pelo menos uma nota de 10 reais e saque for maior ou igual á 10
valores[i]=(valores[i]-1);                       //retirando uma nota de 10 reais
totais[i]=(totais[i]-10);                        //retirando 10 reais do total disponível em notas de 10 reais
saque=(saque-10);                                //retirando 10 reais do saque
s[i]=(s[i]+1);                                   //acrescentando uma nota de 10 reais ao saque
}


if(valores[i]==0) {                            //se não houverem notas de 10 reais
while(valores[i-1]>=2 && saque>=10){           //enquanto houver pelo menos 2 notas de 5 reais e saque for maior ou igual á 10
valores[i-1]=(valores[i-1]-2);                 //retirando 2 notas de 5 reais
totais[i-1]=(totais[i-2]-10);                  //retirando 10 reais do total disponível em notas de 5 reais

valores[i]=(valores[i]+1);                     //acrescentando uma nota de 10 reais
totais[i]=(totais[i]+10);                      //acrescentando 10 reais no total disponível em notas de 10 reais
valores[i]=(valores[i]-1);                     //retirando a nota de 10 acrescentada
totais[i]=(totais[i]-10);                      //retirando os 10 reais acrescentados

saque=(saque-10);                              //retirando 10 reais do saque
s[i]=s[i]+1;                                   //acrescentando uma nota de 10 reais ao saque
}
}

if(valores[i-1]<2) {                           //se não houverem pelo menos 2 notas de 5 reais
while(valores[i-2]>=5 && saque>=10){           //enquanto houverem pelo menos 5 notas de 2 reais e saque for maior ou igual á 10
valores[i-1]=(valores[i-1]-5);                 //retirando 5 notas de 2 reais
totais[i-1]=(totais[i-2]-10);                  //retirando 10 reais do total disponível em notas de 2 reais

valores[i]=(valores[i]+1);                     //acrescentando uma nota de 10 reais
totais[i]=(totais[i]+10);                      //acrescentando 10 reais no total disponível em notas de 10 reais
valores[i]=(valores[i]-1);                     //retirando a nota de 10 reais acrescentada
totais[i]=(totais[i]-10);                      //retirando os 10 reais acrescentados

saque=(saque-10);                              //retirando 10 reais do saque
s[i]=s[i]+1;                                   //acrescentando uma nota de 10 reais ao saque
}
}

i=i-1;                                         //i á partir de agora passa a valer 1, para que sejam buscadas notas de 5 reais para o saque

while (i==1 && valores[i]>=1 && saque>=5){     //enquanto i for igual á 1, houverem notas de 5 reais e saque for maior ou igual á 5
valores[i]=(valores[i]-1);                     //retirando uma nota de 5 reais
totais[i]=(totais[i]-5);                       //retirando 5 reais do total disponível em notas de 5 reais
saque=(saque-5);                               //retirando 5 reais do saque
s[i]=(s[i]+1);                                 //acrescentando 1 nota de 5 reais ao saque
}

if(valores[i]==0) {                           //se não houverem notas de 5 reais
while(valores[i+1]>=1 && saque>=5){           //enquanto houver pelo menos 1 nota de 10 reais e saque for maior ou igual á 5
valores[i+1]=(valores[i+1]-1);                //retirando uma nota de 10 reais
totais[i+1]=(totais[i+1]-10);                 //retirando 10 reais do total disponível em notas de 10 reais

valores[i]=(valores[i]+2);                    //acrescentando 2 notas de 5 reais
totais[i]=(totais[i]+10);                     //acrescentando 10 reais ao total disponível em notas de 5 reais
valores[i]=(valores[i]-1);                    //retirando uma nota de 5 reais, das duas acrescentadas
totais[i]=(totais[i]-5);                      //retirando 5 reais do total acrescentado

saque=(saque-5);                              //retirando 5 reais do saque
s[i]=s[i]+1;                                  //acrescentando 1 nota de 5 reais ao saque
}
}

if(valores[i+1]==0) {                         //se não houverem notas de 10 reais
while(valores[i+2]>=1 && saque>=5){           //enquanto houver uma nota de 20 reais e saque for maior ou igual á 5
valores[i+2]=(valores[i+2]-1);                //retirando uma nota de 20 reais
totais[i+2]=(totais[i+2]-20);                 //retirando 20 reais do total disponível em notas de 20 reais

valores[i]=(valores[i]+4);                    //acrescentando 4 notas de 5 reais
totais[i]=(totais[i]+20);                     //acrescentando 20 reais no total disponível em notas de 5 reais
valores[i]=(valores[i]-1);                    //retirando uma das notas de 5 reais acrescentadas
totais[i]=(totais[i]-5);                      //retirando 5 reais do total acrescentado as notas de 5 reais

saque=(saque-5);                              //retirando 5 reais do saque
s[i]=s[i]+1;                                  //acrescentando uma nota de 5 reais ao saque
}
}

i=i-1;                                       //i á partir de agora passa a valer 0, para que sejam buscadas para o saque notas de 2 reais

while (i==0 && valores[i]>=1 && saque>=2){   //enquanto i for igual a 0, houver pelo menos uma nota de 2 reais e saque for maior ou igual á 2
valores[i]=(valores[i]-1);                   //retirando uma nota de 2 reais
totais[i]=(totais[i]-2);                     //retirando 2 reais do total disponível em notas de 2 reais
saque=(saque-2);                             //retirando 2 reais do saque
s[i]=(s[i]+1);                               //acrescentando uma nota de 2 reais ao saque
}

if(valores[i]==0) {                         //se não houverem notas de 2 reais
while(valores[i+1]>=2 && saque>=2){         //enquanto houver pelo menos uma nota de 5 reais e saque for maior ou igual á 2
valores[i+1]=(valores[i+1]-2);              //retirando 2 notas de 5 reais
totais[i+1]=(totais[i+1]-10);               //retirando 10 reais do total disponível em notas de 5 reais

valores[i]=(valores[i]+5);                  //acrescentando 5 notas de 2 reais
totais[i]=(totais[i]+10);                   //acrescentando 10 reais ao total disponível em notas de 2 reais
valores[i]=(valores[i]-1);                  //retirando uma nota de 2 reais, da quantidade acrescentada
totais[i]=(totais[i]-2);                    //retirando 2 reais do total acrescentado as notas de 2

saque=(saque-2);                            //retirando 2 reais do saque
s[i]=s[i]+1;                                //acrescentando uma nota de 2 reais ao saque
}
}

if(valores[i+1]<2) {                       //se não houverem pelo menos duas notas de 5 reais
while(valores[i+2]>=1 && saque>=2){        //enquanto houver pelo menos uma nota de 10 reais e saque for maior ou igual á 2
valores[i+2]=(valores[i+2]-1);             //retirando uma nota de 10 reais
totais[i+2]=(totais[i+2]-10);              //retirando 10 reais do total disponível em notas de 10

valores[i]=(valores[i]+5);                 //acrescentando 5 notas de 2 reais
totais[i]=(totais[i]+10);                  //acrescentando 10 reais do total disponível em notas de 2 reais
valores[i]=(valores[i]-1);                 //retirando uma das notas de 2 reais acrescentadas
totais[i]=(totais[i]-2);                   //retirando 2 reais do total acrescentado

saque=(saque-2);                           //retirando 2 reais do saque
s[i]=s[i]+1;                               //acrescentando uma nota de 2 reais ao saque
}
}

rot_mostrar(clientes);                            //chamando a rotina rot_mostrar
}  //finalizando a 1ª estrutura enquanto


}  //finalizando a sub rotina

public static void rot_mostrar(Clientes[]clientes){         //declarando o método rot_mostrar
i=5;    //inicializando a variável i com 5 e ela será decrementada posteriormente
//para que sejam exibidas as notas sacadas da maior para a menor

//de acordo com todas estruturas abaixo serão a quantidade de cada tipo
//de nota sacada ao final do processamento

while(i>=0 )
{
if (i==5 && s[i]>0) {
JOptionPane.showMessageDialog(null,+s[i]+" notas de 100 reais");
    }
if (i==4 && s[i]>0){
JOptionPane.showMessageDialog(null,+s[i]+" notas de 50 reais");
    }
if (i==3 && s[i]>0){
JOptionPane.showMessageDialog(null,+s[i]+" notas de 20 reais");
    }
if (i==2 && s[i]>0){
JOptionPane.showMessageDialog(null,+s[i]+" notas de 10 reais");
    }
if (i==1 && s[i]>0){
JOptionPane.showMessageDialog(null,+s[i]+" notas de 5 reais");
    }
if (i==0 && s[i]>0){
JOptionPane.showMessageDialog(null,+s[i]+" notas de 2 reais");
    }
i=i-1;          //ao final de cada verificação a variável i é decrementada

}

//exibindo o novo saldo do cliente
JOptionPane.showMessageDialog(null,"Caro(a) cliente:"+clientes[x].nome+", seu novo saldo é: R$"+clientes[x].saldo);
voltar=15;      //após a realização do saque e exibição da quantidade de cada nota sacada
                //o programa irá retornar ao menu principal

}               //finalizando o método rot_mostrar

public static void rot_estatistica(){          //declarando a rotina de estatística

//tal como na rotina de carregamento do caixa
//para que se realize uma consulta dos saques já realizados
//deve ser informada uma senha de acesso e caso ela seja errada 3 vezes
//o programa irá retornar ao menu principal e acertando a consulta será realizada
s_erros=1;
senha=Integer.parseInt(JOptionPane.showInputDialog("Caro funcionário, por favor insira a sua senha de acesso"));
while(senha!=1229 && senha!=3341 && senha!=4440 && s_erros<3) {
senha=Integer.parseInt(JOptionPane.showInputDialog("Senha inválida, por favor tente novamente, caso o número de\nerros chegue a três o programa retornará ao menu"));
s_erros=(s_erros+1);
}

if(senha==1229 || senha==3341 || senha==4440) {
//Se alguma das 3 senhas de acesso estiver coreta ocorrerá uma comparação banco
//por banco para que sejam verificados o maior e o menor saque, considerando
//que somente o maior saque de cada banco esta armazenado em sua respectiva
//posição no vetor bmaior e o mesmo ocorre com o menor saque de cada banco
//no vetor bmenor. As variáveis que trarão respectivamente o banco de maior
//e de menor saque são bcmaior_saque e bcmenor_saque.
//Foram realizados arranjos de lógicas para que sejam somente exibidos em caso de empate um dos bancos
//de maior saque e de menor saque.
//Caso ocorra de bcmaior_saque ou bcmenor_saque receber 5, ainda não foram realizados saques no caixa.

if((bmaior[0]>=bmaior[1]) && (bmaior[0]>=bmaior[2])&& (bmaior[0]>=bmaior[3]))
bcmaior_saque=1;
else
if((bmaior[1]>bmaior[0]) && (bmaior[1]>=bmaior[2])&& (bmaior[1]>=bmaior[3]))
bcmaior_saque=2;
else
if((bmaior[2]>bmaior[0]) && (bmaior[2]>bmaior[1])&& (bmaior[2]>=bmaior[3]))
bcmaior_saque=3;
else
if((bmaior[3]>bmaior[0]) && (bmaior[3]>bmaior[1])&& (bmaior[3]>bmaior[2]))
bcmaior_saque=4;
else
bcmaior_saque=5;

if((bmenor[0]<=bmenor[1]) && (bmenor[0]<=bmenor[2])&& (bmenor[0]<=bmenor[3]))
bcmenor_saque=1;
else
if((bmenor[1]<bmenor[0]) && (bmenor[1]<=bmenor[2])&& (bmenor[1]<=bmenor[3]))
bcmenor_saque=2;
else
if((bmenor[2]<bmenor[0]) && (bmenor[2]<bmenor[1])&& (bmenor[2]<=bmenor[3]))
bcmenor_saque=3;
else
if((bmenor[3]<bmenor[0]) && (bmenor[3]<bmenor[1])&& (bmenor[3]<bmenor[2]))
bcmenor_saque=4;
else
bcmenor_saque=5;


if(soma_saque!=0 && soma_quant!=0){     //se já tiverem ocorrido saques no caixa
m_saques=(soma_saque/soma_quant);       //a variável m_saques irá calcular a média dos saques realizados para serem exibidos posteriormente
    }

rot_resultados();                       //chamando a rotina rot_resultados
}                                       //finalizando a primeira estrutura de decisão da rotina
}                                       //finalizando a rotina rot_estatistica

public static void rot_resultados(){    //declarando o método rot_resultados

if(bcmaior_saque==5 || bcmenor_saque==5 ||soma_quant==0 || soma_saque==0){          //se a condição estiver satisfeita ainda não foram realizados saques no caixa
JOptionPane.showMessageDialog(null,"Ainda não foram realizados saques e o valor contido no caixa é:\n"+total_geral);
}

else {
//caso contrário serão exibidos os bancos de maior e de menor saque,
//a média dos saques realizados, o valor inicial e atual do caixa

JOptionPane.showMessageDialog(null,"O banco de maior saque é:\n"+bcmaior_saque);
JOptionPane.showMessageDialog(null,"O banco de menor saque é:\n"+bcmenor_saque);
JOptionPane.showMessageDialog(null,"A média total dos saques foi de:"+m_saques);
JOptionPane.showMessageDialog(null,"O valor inicial do caixa era de:"+total_geral);
JOptionPane.showMessageDialog(null,"O valor atual do caixa é:"+total_disponivel);
}

voltar=15;                                 //após exibir os resultados da rotina, o programa irá retornar ao menu principal
}                                          //finalizando a rotina rot_resultados

public static void rot_finalizar(){        //declarando o método rot_finalizar
JOptionPane.showMessageDialog(null,"Muito obrigado, a direção do banco agradece a sua utilização.");
voltar=100;                                //para que o programa seja finalizado, voltar deixa de receber 15 e passa a receber 100
}                                          //finalizando a rotina rot_finalizar
}                                          //finalizando a classe principal do programa



