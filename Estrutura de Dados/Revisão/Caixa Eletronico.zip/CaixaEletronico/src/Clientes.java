public class Clientes {
String nome,rg,cpf,endereco,telefone;
int banco,conta, senha;
double saldo;
}
