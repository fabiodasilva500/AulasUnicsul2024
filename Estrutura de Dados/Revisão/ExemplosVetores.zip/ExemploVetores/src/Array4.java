public class Array4 {
	public static void main(String args[]){
		String mes[] = {"Janeiro", "Fevereiro", "Março", "Abril",
				"Maio", "Junho", "Julho", "Agosto", "Setembro",
				"Outubro", "Novembro", "Dezembro"};
		System.out.printf("%s%12s\n","Índice","Mês");
		for (int i = 0; i < mes.length; i++){
			System.out.printf("%6d",(i+1));
		}
	}
}