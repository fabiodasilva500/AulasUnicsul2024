public class ImprimeVetores{
	public static void main(String[] args){
		int[] vetor={3, 2, 5};
		System.out.println("O vetor possui os valores "+vetor[0]+", "+vetor[1]+" e "+vetor[2]);
	}
}