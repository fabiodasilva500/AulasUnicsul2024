
public class Declaração {
	public static void main(String[]args) {
		int meuInt[] = {450, 200, 1000, 800};
		String meuString[] = {"PROGRAMAÇÃO", "JAVA", "REPROVADO", "REPROVADO N VEZES"};
		float meuFloat[] = {0.0f, 0.5f, 0.8f, 1.0f, 0.8f, 0.5f};
		double meuDouble[] = {0.1, 0.2, 0.3, 0.4, 0.5, 0.6};

		for (int i=0;i<meuInt.length;i++) {
			System.out.println(meuInt[i]);
		}
	}
}
