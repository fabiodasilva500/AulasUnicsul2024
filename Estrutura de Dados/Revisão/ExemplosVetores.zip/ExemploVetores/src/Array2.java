public class Array2 {
	public static void main(String args[]){
		//inicializa os elementos do vetor
		int v[]= {32, 27, 64, 18, 95, 14, 90, 70, 60, 37};
		System.out.printf("%s%8s\n","Indice","Valor");
		for(int i = 0; i < v.length; i++)
			System.out.printf("%5d%8d\n",i, v[i]);
	}
}