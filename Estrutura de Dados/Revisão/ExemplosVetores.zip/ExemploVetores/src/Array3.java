public class Array3 {
	public static void main(String args[]){
		//declara a constante tamanho maximo
		final int TAM_MAX = 10;
		int v[]= new int[TAM_MAX];
		//calcula o valor de cada elemento do array
		for (int i = 0; i < v.length; i++)
			v[i] = 2 + 2*i;
		System.out.printf("%s%8s\n","Indice","Valor");
		//gera a saida do valor de cada elemento do array
		for (int i = 0; i < v.length; i++)
			System.out.printf("%5d%8d\n",i, v[i]);
	}
}