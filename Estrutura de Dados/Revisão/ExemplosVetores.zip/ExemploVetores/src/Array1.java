public class Array1 {
	public static void main(String args[]){
		//declara um array com 10 elementos
		int v[] = new int[10];
		//titulos da coluna
		System.out.printf("%s%8s\n", "Indice","Valor");
		//gera saida do valor de cada elemento do array
		for(int i = 0; i < v.length; i++)
			System.out.printf("%5d%8d\n", i, v[i]);
	} //fim do metodo principal
} //fim da classe