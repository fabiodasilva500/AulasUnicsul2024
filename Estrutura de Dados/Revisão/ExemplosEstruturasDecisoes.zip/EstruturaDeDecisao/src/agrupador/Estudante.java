package agrupador;

public class Estudante {
	public void jogar()
	{
		System.out.println("Deveria estudar estudando");
	}
	
	public void estudar()
	{
		System.out.println("Aluno da FATEC certamente estuda");
	}
}
