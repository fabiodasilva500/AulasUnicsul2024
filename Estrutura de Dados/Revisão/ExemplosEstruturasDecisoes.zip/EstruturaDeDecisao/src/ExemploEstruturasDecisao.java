import agrupador.Estudante;

public class ExemploEstruturasDecisao {


	public static void main(String[]args) {
		int idade = 17;
	 

		if(idade>=65) {
			CalculaAposentadoria calc = new CalculaAposentadoria();
			calc.calcular();
		}
		else 
			if(idade>=18 && idade<65){
				Trabalhador tab = new Trabalhador();
				tab.meuEmprego();
			}
			else {
				Estudante ca = new Estudante();
				ca.jogar();
				ca.estudar();
			}

	}
	
	
	public CalculaAposentadoria metodoRetorno()
	{
		try
		{
			return new CalculaAposentadoria();		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
