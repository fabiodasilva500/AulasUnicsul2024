
public class CalculaAposentadoria {
	public void calcular() {
		double valor = 1200;
		System.out.println(valor);
	}

	public static void main(String[]args) {
		new CalculaAposentadoria();
	}

}

