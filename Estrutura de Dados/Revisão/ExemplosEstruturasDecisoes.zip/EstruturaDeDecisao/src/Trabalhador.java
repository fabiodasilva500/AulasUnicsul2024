
public class Trabalhador {
	public void meuEmprego() {
		double salario = 1000;
		System.out.println("Sal�rio m�dio do programador:"+salario);
	}
}
